function numgrad = checkGradient2(J, theta, thetaSize, X, y, parameters)
% Calculate numerical gradients
% theta: a vector of parameters
% J: a function that outputs a real-number. Calling y = J(theta) will 
% return the function value at theta.

%=======================================================================
m = size(X, 2);
numClasses = length(unique(y));
y = full(sparse(y, 1:m, 1));
J1 = 0;
J2 = 0;
%=======================================================================


numgrad = zeros(size(theta));
epsilon = 1e-4;

for i=1:length(theta)
    e=zeros(size(theta));
    e(i)=epsilon;
    
    %========================================================
    % Reshape theta to the network parameters
    theta1=theta+e;
    [W1, W2, b1, b2] = theta2params(theta1, thetaSize);
    
    z2 = (W1*X) + b1;
    a2 = sigmoid(z2);
    z3 = (W2*a2) + b2;
    a3 = sigmoid(z3);

    J1 = (mean((a3-y).^2))./2;
    %========================================================
    % Reshape theta to the network parameters
    theta2=theta-e;
    [W1, W2, b1, b2] = theta2params(theta2, thetaSize);
    
    z2 = (W1*X) + b1;
    a2 = sigmoid(z2);
    z3 = (W2*a2) + b2;
    a3 = sigmoid(z3);

    J2 = (mean((a3-y).^2))./2;
    %========================================================
    numgrad(i,1)=mean((J1-J2)/(2*epsilon));
end

end
