function g = sigmoid(z)
% Compute sigmoid function.

g = 1./(1+exp(-z));

end
