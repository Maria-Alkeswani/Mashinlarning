function [J, grad] = costLogisticRegression(theta, X, y, lambda)
% Compute cost and gradient for logistic regression.

if nargin<4
    lambda = 0;
end

m = length(y); % number of training examples

% You need to return the following variables correctly 
J = 0;
grad = zeros(size(theta));

% ====================== YOUR CODE HERE ======================
% Compute the cost (J) and partial derivatives (grad) of a particular 
% choice of theta. Make use of the function sigmoid.m that you wrote earlier.

% J = ...
% grad = ...
    sig = sigmoid(X * theta);   % hypothesis logistic regression
    
    theta2=theta(2:end).^2;
    
    reg1=(lambda/(2*m))*sum(theta2);
    
    h1=(-y).*log(sig);
    h2=(1-y).*log(1-sig);
    J=mean(h1-h2)+reg1;
    
    theta_reg = theta;
    theta_reg(1) = 0;
    
    g1=X'*(sig-y)./m;
    g2=theta_reg*lambda/m;
    grad=g1+g2;
% =============================================================

% unroll gradients
grad = grad(:);

end
