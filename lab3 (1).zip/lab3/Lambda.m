function [trainerror1,valerror1] = Lambda(Xtrain,ytrain,Xval,yval,initial_theta,lambda_list)
%LAMBDA Summary of this function goes here
%   Detailed explanation goes here

options = struct('display', 'on', 'Method', 'lbfgs', 'maxIter', 400);
trainerror1=zeros(size(lambda_list));
valerror1=zeros(size(lambda_list));

for i=1:1:length(lambda_list)
    lambda0 = lambda_list(1,i);
    theta0 = fmincg(@(p)(costLogisticRegression(p, Xtrain, ytrain, lambda0)), initial_theta, options);

    trainaccuracy0 = mean(round(sigmoid(Xtrain*theta0))==ytrain);
    valaccuracy0 = mean(round(sigmoid(Xval*theta0))==yval);

    trainerror0 = 1 - trainaccuracy0;
    valerror0 = 1 - valaccuracy0;
    
    trainerror1(1,i)=trainerror0;
    valerror1(1,i)=valerror0;
    
end

figure;
plot(lambda_list,valerror1,"r-")
title('Val Error');
xlabel('lambda');
ylabel('error');

figure;
plot(lambda_list,trainerror1,"r-")
title('Train Error');
xlabel('lambda');
ylabel('error');


end

